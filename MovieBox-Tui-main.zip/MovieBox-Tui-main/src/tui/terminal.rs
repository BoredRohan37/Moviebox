fn env(name: &str) -> String {
    std::env::var(name).unwrap_or_default()
}

/// True on a legacy Windows console (Windows 7/8.1 conhost) that cannot process ANSI
/// escape sequences. On such consoles crossterm falls back to the old WinAPI path,
/// which only understands the 16 named colors (RGB/256-color values render as black),
/// so the app must use the basic theme and skip image protocols.
///
/// Override with `MOVIEBOX_LEGACY_CONSOLE=1` (force on) or `=0` (force off).
pub fn is_legacy_windows_console() -> bool {
    #[cfg(target_os = "windows")]
    {
        static LEGACY: std::sync::LazyLock<bool> = std::sync::LazyLock::new(|| {
            if let Ok(value) = std::env::var("MOVIEBOX_LEGACY_CONSOLE") {
                let value = value.trim();
                if value == "1" || value.eq_ignore_ascii_case("true") {
                    return true;
                }
                if value == "0" || value.eq_ignore_ascii_case("false") {
                    return false;
                }
            }
            !crossterm::ansi_support::supports_ansi()
        });
        *LEGACY
    }
    #[cfg(not(target_os = "windows"))]
    {
        false
    }
}

pub fn uses_basic_ui() -> bool {
    let term = env("TERM");
    if term == "dumb" || term == "linux" {
        return true;
    }
    crate::tui::theme::ColorSupport::current() == crate::tui::theme::ColorSupport::Basic
}
fn is_inside_tmux() -> bool {
    std::env::var("TMUX").is_ok()
}

fn outer_terminal_supports_graphics() -> bool {
    if std::env::var("GHOSTTY_RESOURCES_DIR").is_ok()
        || std::env::var("KITTY_WINDOW_ID").is_ok()
        || std::env::var("WEZTERM_EXECUTABLE").is_ok()
        || std::env::var("ITERM_SESSION_ID").is_ok()
        || std::env::var("ALACRITTY_LOG").is_ok()
        || std::env::var("ALACRITTY_WINDOW_ID").is_ok()
        || std::env::var("ALACRITTY_SOCKET").is_ok()
        || std::env::var("KONSOLE_VERSION").is_ok()
        || std::env::var("WT_SESSION").is_ok()
    {
        return true;
    }
    let term = env("TERM").to_ascii_lowercase();
    if term.starts_with("foot")
        || term.contains("kitty")
        || term.contains("ghostty")
        || term.contains("alacritty")
    {
        return true;
    }
    let term_program = env("TERM_PROGRAM").to_ascii_lowercase();
    matches!(
        term_program.as_str(),
        "ghostty" | "wezterm" | "iterm.app" | "vscode" | "rio"
    )
}

pub fn should_query_images() -> bool {
    if std::env::var("MOVIEBOX_NO_IMAGE").is_ok_and(|v| v == "1" || v.eq_ignore_ascii_case("true"))
    {
        return false;
    }
    if let Ok(forced) = std::env::var("MOVIEBOX_IMAGE_PROTOCOL") {
        let forced = forced.trim();
        if forced.eq_ignore_ascii_case("none")
            || forced.eq_ignore_ascii_case("off")
            || forced.eq_ignore_ascii_case("false")
        {
            return false;
        }
        if !forced.is_empty() {
            return true;
        }
    }
    if is_legacy_windows_console() {
        return false;
    }
    if is_inside_tmux()
        && std::env::var("MOVIEBOX_IMAGE_PROTOCOL").is_err()
        && !outer_terminal_supports_graphics()
    {
        return false;
    }
    if std::env::var("TERM_PROGRAM").is_ok_and(|v| v == "Apple_Terminal") {
        return false;
    }
    let term = env("TERM");
    if term == "dumb"
        || term == "linux"
        || term == "cygwin"
        || term.starts_with("vt")
        || term.starts_with("cons")
    {
        return false;
    }
    #[cfg(target_os = "windows")]
    {
        let is_modern_terminal = std::env::var("WT_SESSION").is_ok()
            || std::env::var("TERM_PROGRAM").is_ok()
            || std::env::var("ALACRITTY_LOG").is_ok()
            || std::env::var("ALACRITTY_SOCKET").is_ok()
            || std::env::var("WEZTERM_EXECUTABLE").is_ok()
            || std::env::var("GHOSTTY_RESOURCES_DIR").is_ok()
            || term.contains("alacritty")
            || term.contains("kitty")
            || term.contains("ghostty");
        if !is_modern_terminal {
            return false;
        }
    }
    true
}

pub fn background_is_light() -> bool {
    if let Ok(value) = std::env::var("COLORFGBG")
        && let Some(background) = value
            .split([';', ':'])
            .next_back()
            .and_then(|value| value.parse::<u8>().ok())
    {
        return matches!(background, 7 | 10..=15);
    }

    std::env::var("TERM_BACKGROUND")
        .or_else(|_| std::env::var("BACKGROUND"))
        .is_ok_and(|value| value.eq_ignore_ascii_case("light"))
}

pub fn set_window_title(title: &str) -> std::io::Result<()> {
    crossterm::execute!(std::io::stdout(), crossterm::terminal::SetTitle(title))
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_should_query_images_guards() {
        unsafe {
            std::env::set_var("MOVIEBOX_NO_IMAGE", "1");
            assert!(!should_query_images());
            std::env::remove_var("MOVIEBOX_NO_IMAGE");

            std::env::set_var("MOVIEBOX_IMAGE_PROTOCOL", "none");
            assert!(!should_query_images());
            std::env::remove_var("MOVIEBOX_IMAGE_PROTOCOL");

            std::env::set_var("TERM_PROGRAM", "Apple_Terminal");
            assert!(!should_query_images());
            std::env::remove_var("TERM_PROGRAM");

            std::env::set_var("TERM", "dumb");
            assert!(!should_query_images());
            std::env::remove_var("TERM");
            std::env::set_var("MOVIEBOX_IMAGE_PROTOCOL", "kitty");
            assert!(should_query_images());
            std::env::remove_var("MOVIEBOX_IMAGE_PROTOCOL");
            let saved_vars = [
                "GHOSTTY_RESOURCES_DIR",
                "KITTY_WINDOW_ID",
                "WEZTERM_EXECUTABLE",
                "ITERM_SESSION_ID",
                "ALACRITTY_LOG",
                "ALACRITTY_WINDOW_ID",
                "ALACRITTY_SOCKET",
                "KONSOLE_VERSION",
                "WT_SESSION",
                "TERM_PROGRAM",
            ]
            .map(|k| (k, std::env::var(k).ok()));

            for (k, _) in &saved_vars {
                std::env::remove_var(k);
            }

            std::env::set_var("TMUX", "/tmp/tmux-1000/default,12345,0");
            assert!(!should_query_images());

            std::env::set_var("GHOSTTY_RESOURCES_DIR", "/usr/share/ghostty");
            assert!(should_query_images());
            std::env::remove_var("GHOSTTY_RESOURCES_DIR");

            std::env::set_var("MOVIEBOX_IMAGE_PROTOCOL", "kitty");
            assert!(should_query_images());
            std::env::remove_var("MOVIEBOX_IMAGE_PROTOCOL");
            std::env::remove_var("TMUX");

            for (k, val) in saved_vars {
                if let Some(v) = val {
                    std::env::set_var(k, v);
                }
            }
        }
    }
}
